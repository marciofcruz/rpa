# DividirOrdemServico
Projeto desenvolvido por Thiago Fernandes Cruz para fazer o processamento de divisão de um arquivo com vários cartões de ponto, separando por funcionários.

### Como configurar:
separar de 2 em 2 páginas e colocar no título o nome e matrícula da pessoa. Salvar em pdf.

Será neceário identificar os textos por OCR.

### Como executar:
pip install -r requerements.txt
configuar app-config.properties
python DividirOrdemServico.py -> Executar processo