# ExtrairCamposArquivoSEFIP
Projeto desenvolvido por Thiago Fernandes Cruz para fazer a separação de página do relatório SEFIP

### Como configurar:
ediar o arquivo app-config.properties e, editar os par6metros

### Como executar:
pip install -r requeriments.txt
configuar app-config.properties
python ExtrairCamposArquivoSEFIP.py -> Executar processo

### O que vai ser feito na pasta output:
Separar sempre as 3 últimas páginas do arquivo RE (os arquivos possuem quantidades diferentes de páginas)

No título:
RE_cnpj, a competência , a data de emissão e o horário